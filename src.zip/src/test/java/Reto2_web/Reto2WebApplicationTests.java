package Reto2_web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto2WebApplicationTests {

	@Test
	void contextLoads() {
	}

}
